function Error(){
    return(
        <>
            <div className="error">
                <h1>Nic tutaj nie ma</h1>
            </div>
        </>
    )
}
export default Error