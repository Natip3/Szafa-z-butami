import Zalogowany from "../components/Zalogowany.jsx";
import Footer from "../components/Footer.jsx";

function Zalogowanypoprawnie(){
    return(
        <div className="page-wrapper">
            <Zalogowany/>
            <Footer/>
        </div>
    )
}
export default Zalogowanypoprawnie